import ui.MainFrame;
import javax.swing.SwingUtilities;

/**
 * ================================================================
 *  PREDIÇÃO DE PREÇOS DE CASAS — IA com Regressão Linear Múltipla
 * ================================================================
 *
 * Grupo 18 | 2º Ano — Engenharia Informática | Linguagem de Prog. IV
 * Integrante: João da Costa Faustino
 *
 * ESTRUTURA DO PROJETO:
 * ├── Main.java
 * ├── model/
 * │   ├── Casa.java                 ← Entidade imóvel (features + preço)
 * │   └── ResultadoRegressao.java   ← Coeficientes β e métricas R², RMSE...
 * ├── service/
 * │   ├── MotorRegressao.java       ← MATEMÁTICA PURA: OLS, Gauss-Jordan, métricas
 * │   └── GestaoPredicao.java       ← Coordenação: dataset, treino, predição
 * ├── util/
 * │   └── JsonUtil.java             ← Persistência em JSON sem bibliotecas
 * └── ui/
 *     ├── MainFrame.java            ← Janela principal (5 abas)
 *     ├── DashboardPanel.java       ← Estatísticas + correlações
 *     ├── DatasetPanel.java         ← Tabela de casas com CRUD
 *     ├── PredicaoPanel.java        ← Sliders para prever preço
 *     ├── ModeloPanel.java          ← Coeficientes + equação do modelo
 *     └── GraficoPanel.java         ← Scatter plot com Graphics2D
 *
 * MATEMÁTICA IMPLEMENTADA DO ZERO (sem bibliotecas):
 * - Regressão Linear Múltipla (OLS)
 * - Produto matricial e transposta
 * - Inversão de matriz (Eliminação de Gauss-Jordan)
 * - Métricas: R², RMSE, MAE, MAPE
 * - Correlação de Pearson
 * - Gráfico de dispersão com Graphics2D
 *
 * @version 1.0 — 2025
 */
public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            System.out.println("=== Predição de Preços de Casas ===");
            System.out.println("Iniciando aplicação...");
            new MainFrame();
        });
    }
}

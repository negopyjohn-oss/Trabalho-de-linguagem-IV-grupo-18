package ui;

import model.Casa;
import service.GestaoPredicao;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;

public class DatasetPanel extends JPanel implements MainFrame.Atualizavel {

    private GestaoPredicao gestao;
    private MainFrame mainFrame;
    private JTable tabela;
    private DefaultTableModel modelo;
    private JLabel lblInfo;

    private static final String[] COLUNAS = {
        "ID", "Área (m²)", "Quartos", "Banheiros", "Idade (anos)", "Dist. Centro (km)", "Preço Real (Kz)", "Preço Previsto (Kz)", "Erro (%)"
    };

    public DatasetPanel(GestaoPredicao gestao, MainFrame mainFrame) {
        this.gestao = gestao; this.mainFrame = mainFrame;
        setBackground(MainFrame.FUNDO);
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        construir();
        atualizar();
    }

    private void construir() {
        JLabel titulo = new JLabel("📊 Dataset de Casas");
        titulo.setFont(MainFrame.F_TITULO); titulo.setForeground(MainFrame.VERDE_ESCURO);
        titulo.setBorder(BorderFactory.createEmptyBorder(0, 0, 12, 0));

        lblInfo = new JLabel("Carregando...");
        lblInfo.setFont(MainFrame.F_PEQUENA); lblInfo.setForeground(MainFrame.TEXTO_CLARO);

        JPanel topo = new JPanel(new BorderLayout());
        topo.setOpaque(false);
        topo.add(titulo, BorderLayout.WEST);
        topo.add(lblInfo, BorderLayout.EAST);
        add(topo, BorderLayout.NORTH);

        modelo = new DefaultTableModel(COLUNAS, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
            @Override public Class<?> getColumnClass(int c) {
                return c == 0 ? String.class : Double.class;
            }
        };

        tabela = new JTable(modelo);
        tabela.setRowHeight(32);
        tabela.setFont(MainFrame.F_NORMAL);
        tabela.setShowVerticalLines(false);
        tabela.setGridColor(MainFrame.BORDA);
        tabela.setSelectionBackground(MainFrame.VERDE_CLARO);
        tabela.setSelectionForeground(MainFrame.TEXTO);

        JTableHeader h = tabela.getTableHeader();
        h.setFont(MainFrame.F_SUBTIT);
        h.setBackground(MainFrame.VERDE_ESCURO);
        h.setForeground(Color.WHITE);
        h.setReorderingAllowed(false);

        // Larguras
        int[] larg = {60, 90, 80, 90, 100, 130, 120, 130, 80};
        for (int i = 0; i < larg.length; i++)
            tabela.getColumnModel().getColumn(i).setPreferredWidth(larg[i]);

        // Renderer para coluna Erro (%)
        tabela.getColumnModel().getColumn(8).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
                JLabel l = (JLabel) super.getTableCellRendererComponent(t, v, sel, foc, r, c);
                l.setHorizontalAlignment(SwingConstants.CENTER);
                if (v instanceof Double) {
                    double pct = (Double) v;
                    l.setText(String.format("%.1f%%", pct));
                    if (!sel) {
                        if (pct < 5)  { l.setBackground(new Color(200, 240, 200)); l.setForeground(MainFrame.VERDE_ESCURO); }
                        else if (pct < 15) { l.setBackground(new Color(255, 243, 200)); l.setForeground(MainFrame.LARANJA); }
                        else          { l.setBackground(new Color(255, 210, 210)); l.setForeground(MainFrame.VERMELHO); }
                    }
                }
                return l;
            }
        });

        // Renderer de preço formatado
        DefaultTableCellRenderer rendPreco = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
                if (v instanceof Double) setText(String.format("%,.0f Kz", (Double)v));
                return super.getTableCellRendererComponent(t, v != null ? getText() : "", sel, foc, r, c);
            }
        };
        rendPreco.setHorizontalAlignment(SwingConstants.RIGHT);
        tabela.getColumnModel().getColumn(6).setCellRenderer(rendPreco);
        tabela.getColumnModel().getColumn(7).setCellRenderer(rendPreco);

        // Linhas alternadas
        tabela.setDefaultRenderer(Double.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
                JLabel l = (JLabel) super.getTableCellRendererComponent(t, v, sel, foc, r, c);
                l.setHorizontalAlignment(SwingConstants.CENTER);
                if (v instanceof Double) l.setText(String.format("%.1f", (Double)v));
                if (!sel) l.setBackground(r % 2 == 0 ? Color.WHITE : new Color(245, 250, 245));
                return l;
            }
        });

        JScrollPane scroll = new JScrollPane(tabela);
        scroll.setBorder(BorderFactory.createLineBorder(MainFrame.BORDA));
        add(scroll, BorderLayout.CENTER);

        // Botões
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        btnPanel.setBackground(MainFrame.FUNDO);
        JButton btnAdd    = MainFrame.criarBotao("➕ Adicionar Casa", MainFrame.VERDE_MEDIO);
        JButton btnRemove = MainFrame.criarBotao("🗑️ Remover", MainFrame.VERMELHO);
        btnAdd.addActionListener(e -> abrirDialogoAdicionar());
        btnRemove.addActionListener(e -> removerSelecionada());
        btnPanel.add(btnAdd); btnPanel.add(btnRemove);
        add(btnPanel, BorderLayout.SOUTH);
    }

    @Override
    public void atualizar() {
        modelo.setRowCount(0);
        List<Casa> casas = gestao.getDataset();
        for (Casa c : casas) {
            modelo.addRow(new Object[]{
                c.getId(), c.getAreaM2(), (double)c.getQuartos(), (double)c.getBanheiros(),
                (double)c.getIdadeAnos(), c.getDistanciaCentroKm(), c.getPrecoReal(),
                c.getPrecoPredicao() > 0 ? c.getPrecoPredicao() : null,
                c.getPrecoPredicao() > 0 ? c.getErroPercentual() : null
            });
        }
        lblInfo.setText(casas.size() + " registros no dataset");
        revalidate(); repaint();
    }

    private void abrirDialogoAdicionar() {
        JDialog d = new JDialog(mainFrame, "➕ Adicionar Casa ao Dataset", true);
        d.setLayout(new BorderLayout());
        d.setSize(420, 340);
        d.setLocationRelativeTo(mainFrame);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Color.WHITE);
        form.setBorder(BorderFactory.createEmptyBorder(15, 20, 10, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        JTextField fArea  = new JTextField("80.0",  10);
        JSpinner   sQua   = new JSpinner(new SpinnerNumberModel(2, 1, 10, 1));
        JSpinner   sBan   = new JSpinner(new SpinnerNumberModel(1, 1, 6, 1));
        JSpinner   sIdade = new JSpinner(new SpinnerNumberModel(5, 0, 80, 1));
        JTextField fDist  = new JTextField("10.0",  10);
        JTextField fPreco = new JTextField("85000", 10);

        String[][] campos = {{"Área (m²):",null},{"Quartos:",null},{"Banheiros:",null},
                             {"Idade (anos):",null},{"Distância ao centro (km):",null},{"Preço Real (Kz):",null}};
        Component[] comps = {fArea, sQua, sBan, sIdade, fDist, fPreco};

        for (int i = 0; i < comps.length; i++) {
            gbc.gridx = 0; gbc.gridy = i; gbc.weightx = 0.4;
            JLabel lbl = new JLabel(campos[i][0]); lbl.setFont(MainFrame.F_NORMAL);
            form.add(lbl, gbc);
            gbc.gridx = 1; gbc.weightx = 0.6;
            form.add(comps[i], gbc);
        }

        JPanel btn = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btn.setBackground(Color.WHITE);
        JButton ok  = MainFrame.criarBotao("💾 Adicionar", MainFrame.VERDE_MEDIO);
        JButton can = MainFrame.criarBotao("Cancelar", new Color(100,100,100));
        ok.addActionListener(e -> {
            try {
                double area  = Double.parseDouble(fArea.getText().trim());
                int    qua   = (Integer) sQua.getValue();
                int    ban   = (Integer) sBan.getValue();
                int    idade = (Integer) sIdade.getValue();
                double dist  = Double.parseDouble(fDist.getText().trim());
                double preco = Double.parseDouble(fPreco.getText().trim());
                gestao.adicionarCasa(area, qua, ban, idade, dist, preco);
                mainFrame.atualizarTudo();
                d.dispose();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(d, "Valores inválidos!", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });
        can.addActionListener(e -> d.dispose());
        btn.add(can); btn.add(ok);
        d.add(form, BorderLayout.CENTER);
        d.add(btn, BorderLayout.SOUTH);
        d.setVisible(true);
    }

    private void removerSelecionada() {
        int row = tabela.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Selecione uma casa!", "Aviso", JOptionPane.WARNING_MESSAGE); return; }
        String id = (String) modelo.getValueAt(row, 0);
        if (JOptionPane.showConfirmDialog(this, "Remover casa " + id + "?", "Confirmar", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            gestao.removerCasa(id);
            mainFrame.atualizarTudo();
        }
    }
}

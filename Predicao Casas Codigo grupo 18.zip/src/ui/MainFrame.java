package ui;

import service.GestaoPredicao;

import javax.swing.*;
import java.awt.*;

/**
 * MainFrame — janela principal da aplicação de Predição de Preços.
 * Herda de JFrame (Herança — POO).
 */
public class MainFrame extends JFrame {

    private GestaoPredicao gestao;
    private JTabbedPane    abas;

    // ── Paleta de cores ─────────────────────────────────────────────
    public static final Color VERDE_ESCURO  = new Color(27,  94,  32);
    public static final Color VERDE_MEDIO   = new Color(56, 142,  60);
    public static final Color VERDE_CLARO   = new Color(200, 230, 201);
    public static final Color AZUL_IA       = new Color(21,  101, 192);
    public static final Color LARANJA       = new Color(230, 119,   0);
    public static final Color VERMELHO      = new Color(198,  40,  40);
    public static final Color FUNDO         = new Color(245, 248, 245);
    public static final Color CARTAO        = Color.WHITE;
    public static final Color TEXTO         = new Color(33,  37,  41);
    public static final Color TEXTO_CLARO   = new Color(100, 110, 100);
    public static final Color BORDA         = new Color(200, 220, 200);

    public static final Font F_TITULO  = new Font("Segoe UI", Font.BOLD, 22);
    public static final Font F_SUBTIT  = new Font("Segoe UI", Font.BOLD, 14);
    public static final Font F_NORMAL  = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font F_PEQUENA = new Font("Segoe UI", Font.PLAIN, 11);
    public static final Font F_MONO    = new Font("Courier New", Font.PLAIN, 12);

    public MainFrame() {
        this.gestao = new GestaoPredicao();
        configurar();
        construirUI();
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void configurar() {
        setTitle("🏠 Predição de Preços de Casas — IA Regressão Linear");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1150, 720));
        setPreferredSize(new Dimension(1250, 800));
        getContentPane().setBackground(FUNDO);
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
        catch (Exception ignored) {}
    }

    private void construirUI() {
        setLayout(new BorderLayout());
        add(criarCabecalho(), BorderLayout.NORTH);

        abas = new JTabbedPane(JTabbedPane.TOP);
        abas.setFont(F_SUBTIT);
        abas.setBackground(FUNDO);

        DashboardPanel    dashboard  = new DashboardPanel(gestao, this);
        DatasetPanel      dataset    = new DatasetPanel(gestao, this);
        PredicaoPanel     predicao   = new PredicaoPanel(gestao, this);
        ModeloPanel       modeloP    = new ModeloPanel(gestao, this);
        GraficoPanel      grafico    = new GraficoPanel(gestao, this);

        abas.addTab("  🏠 Dashboard     ", dashboard);
        abas.addTab("  📊 Dataset       ", dataset);
        abas.addTab("  🤖 Predição      ", predicao);
        abas.addTab("  📐 Modelo        ", modeloP);
        abas.addTab("  📈 Gráfico       ", grafico);

        add(abas, BorderLayout.CENTER);
        add(criarRodape(), BorderLayout.SOUTH);
    }

    private JPanel criarCabecalho() {
        JPanel h = new JPanel(new BorderLayout());
        h.setBackground(VERDE_ESCURO);
        h.setBorder(BorderFactory.createEmptyBorder(14, 25, 14, 25));

        JPanel esq = new JPanel(new GridLayout(2, 1));
        esq.setOpaque(false);
        JLabel t1 = new JLabel("🏠 Predição de Preços de Casas — IA com Regressão Linear Múltipla");
        t1.setFont(new Font("Segoe UI", Font.BOLD, 22));
        t1.setForeground(Color.WHITE);
        JLabel t2 = new JLabel("Grupo 18 · 2º Ano / Engenharia Informática · Linguagem de Programação IV  |  João da Costa Faustino");
        t2.setFont(F_PEQUENA);
        t2.setForeground(new Color(180, 230, 180));
        esq.add(t1); esq.add(t2);

        JButton btnTreinar = criarBotao("⚙️ Treinar Modelo", AZUL_IA);
        btnTreinar.addActionListener(e -> {
            try {
                gestao.treinarModelo();
                atualizarTudo();
                JOptionPane.showMessageDialog(this,
                    "✅ Modelo treinado com sucesso!\nR² = " + String.format("%.4f", gestao.getModelo().getR2()),
                    "Modelo Treinado", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });

        h.add(esq, BorderLayout.WEST);
        h.add(btnTreinar, BorderLayout.EAST);
        return h;
    }

    private JPanel criarRodape() {
        JPanel r = new JPanel(new FlowLayout(FlowLayout.CENTER));
        r.setBackground(new Color(33, 33, 33));
        r.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        JLabel l = new JLabel("💾 Dataset persistido em JSON  |  Regressão Linear Múltipla implementada do zero (sem bibliotecas)  |  OLS — Mínimos Quadrados");
        l.setFont(F_PEQUENA);
        l.setForeground(new Color(170, 170, 170));
        r.add(l);
        return r;
    }

    public void atualizarTudo() {
        for (int i = 0; i < abas.getTabCount(); i++) {
            Component c = abas.getComponentAt(i);
            if (c instanceof Atualizavel) ((Atualizavel) c).atualizar();
        }
    }

    // ── Helpers estáticos reutilizados pelos painéis ─────────────────

    public static JButton criarBotao(String txt, Color cor) {
        JButton b = new JButton(txt);
        b.setFont(F_NORMAL);
        b.setBackground(cor);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b.setBorder(BorderFactory.createEmptyBorder(8, 18, 8, 18));
        Color escura = cor.darker();
        b.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) { b.setBackground(escura); }
            public void mouseExited (java.awt.event.MouseEvent e) { b.setBackground(cor); }
        });
        return b;
    }

    public static JPanel criarCartao(String titulo, Color corBorda) {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(CARTAO);
        p.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 4, 0, 0, corBorda),
            BorderFactory.createEmptyBorder(12, 14, 12, 14)));
        if (titulo != null) {
            JLabel l = new JLabel(titulo);
            l.setFont(F_SUBTIT);
            l.setForeground(TEXTO);
            l.setBorder(BorderFactory.createEmptyBorder(0, 0, 8, 0));
            p.add(l, BorderLayout.NORTH);
        }
        return p;
    }

    public GestaoPredicao getGestao() { return gestao; }

    /** Interface para painéis que podem ser atualizados */
    public interface Atualizavel {
        void atualizar();
    }
}

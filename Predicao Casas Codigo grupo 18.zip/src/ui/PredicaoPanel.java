package ui;

import service.GestaoPredicao;

import javax.swing.*;
import java.awt.*;

public class PredicaoPanel extends JPanel implements MainFrame.Atualizavel {

    private GestaoPredicao gestao;
    private MainFrame mainFrame;

    // Campos de entrada
    private JSlider  slArea, slQuartos, slBanheiros, slIdade;
    private JSlider  slDistancia;
    private JLabel   lblArea, lblQuartos, lblBanheiros, lblIdade, lblDist;

    // Resultado
    private JLabel   lblResultado, lblFaixa, lblInterpretacao;
    private JPanel   painelResultado;

    public PredicaoPanel(GestaoPredicao gestao, MainFrame mainFrame) {
        this.gestao = gestao; this.mainFrame = mainFrame;
        setBackground(MainFrame.FUNDO);
        setLayout(new BorderLayout(15, 15));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        construir();
    }

    private void construir() {
        JLabel titulo = new JLabel("🤖 Prever Preço de uma Nova Casa");
        titulo.setFont(MainFrame.F_TITULO); titulo.setForeground(MainFrame.VERDE_ESCURO);
        titulo.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        add(titulo, BorderLayout.NORTH);

        // ── Formulário com sliders ───────────────────────────────────
        JPanel formulario = new JPanel(new GridBagLayout());
        formulario.setBackground(MainFrame.CARTAO);
        formulario.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(MainFrame.BORDA),
            BorderFactory.createEmptyBorder(20, 25, 20, 25)));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 8, 8, 8);

        // Cabeçalho do formulário
        JLabel hdr = new JLabel("📋 Características da Casa");
        hdr.setFont(MainFrame.F_SUBTIT); hdr.setForeground(MainFrame.AZUL_IA);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 3;
        formulario.add(hdr, gbc);
        gbc.gridwidth = 1;

        // ─ Área
        slArea       = new JSlider(20, 300, 100);
        lblArea      = new JLabel("100 m²");
        adicionarSlider(formulario, gbc, 1, "📐 Área:", slArea, lblArea, " m²", 20, 300, 10);

        // ─ Quartos
        slQuartos    = new JSlider(1, 8, 3);
        lblQuartos   = new JLabel("3");
        adicionarSlider(formulario, gbc, 2, "🛏️ Quartos:", slQuartos, lblQuartos, "", 1, 8, 1);

        // ─ Banheiros
        slBanheiros  = new JSlider(1, 5, 2);
        lblBanheiros = new JLabel("2");
        adicionarSlider(formulario, gbc, 3, "🚿 Banheiros:", slBanheiros, lblBanheiros, "", 1, 5, 1);

        // ─ Idade
        slIdade      = new JSlider(0, 50, 5);
        lblIdade     = new JLabel("5 anos");
        adicionarSlider(formulario, gbc, 4, "🏗️ Idade:", slIdade, lblIdade, " anos", 0, 50, 5);

        // ─ Distância
        slDistancia  = new JSlider(1, 30, 8);
        lblDist      = new JLabel("8,0 km");
        adicionarSlider(formulario, gbc, 5, "📍 Distância:", slDistancia, lblDist, " km", 1, 30, 5);

        // Botão prever
        JButton btnPrever = MainFrame.criarBotao("🤖 PREVER PREÇO", MainFrame.AZUL_IA);
        btnPrever.setFont(new Font("Segoe UI", Font.BOLD, 15));
        gbc.gridx = 0; gbc.gridy = 6; gbc.gridwidth = 3;
        gbc.insets = new Insets(20, 8, 5, 8);
        formulario.add(btnPrever, gbc);
        btnPrever.addActionListener(e -> prever());

        // ── Painel de resultado ──────────────────────────────────────
        painelResultado = new JPanel(new GridLayout(3, 1, 5, 5));
        painelResultado.setBackground(MainFrame.CARTAO);
        painelResultado.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 5, 0, 0, MainFrame.AZUL_IA),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)));

        lblResultado     = new JLabel("—");
        lblResultado.setFont(new Font("Segoe UI", Font.BOLD, 36));
        lblResultado.setForeground(MainFrame.AZUL_IA);
        lblResultado.setHorizontalAlignment(SwingConstants.CENTER);

        lblFaixa         = new JLabel("Treine o modelo primeiro");
        lblFaixa.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblFaixa.setForeground(MainFrame.TEXTO_CLARO);
        lblFaixa.setHorizontalAlignment(SwingConstants.CENTER);

        lblInterpretacao = new JLabel(" ");
        lblInterpretacao.setFont(MainFrame.F_NORMAL);
        lblInterpretacao.setForeground(MainFrame.TEXTO);
        lblInterpretacao.setHorizontalAlignment(SwingConstants.CENTER);

        painelResultado.add(lblResultado);
        painelResultado.add(lblFaixa);
        painelResultado.add(lblInterpretacao);

        // Layout central
        JPanel centro = new JPanel(new GridLayout(1, 2, 20, 0));
        centro.setBackground(MainFrame.FUNDO);
        centro.add(formulario);

        JPanel dirPanel = new JPanel(new BorderLayout(0, 15));
        dirPanel.setBackground(MainFrame.FUNDO);
        dirPanel.add(painelResultado, BorderLayout.NORTH);
        dirPanel.add(criarExplicacaoMath(), BorderLayout.CENTER);
        centro.add(dirPanel);

        add(centro, BorderLayout.CENTER);
    }

    private void adicionarSlider(JPanel p, GridBagConstraints gbc,
            int row, String label, JSlider slider, JLabel lblVal,
            String sufixo, int min, int max, int tick) {
        slider.setBackground(MainFrame.CARTAO);
        slider.setPaintTicks(true);
        slider.setMajorTickSpacing(tick * 5);
        slider.setMinorTickSpacing(tick);
        slider.addChangeListener(e -> {
            String txt = sufixo.contains("m²") ? slider.getValue() + " m²" :
                         sufixo.contains("km") ? slider.getValue() + ",0 km" :
                         sufixo.contains("anos") ? slider.getValue() + " anos" :
                         String.valueOf(slider.getValue());
            lblVal.setText(txt);
        });

        gbc.gridx = 0; gbc.gridy = row; gbc.weightx = 0.25; gbc.insets = new Insets(6, 8, 6, 8);
        JLabel lbl = new JLabel(label); lbl.setFont(MainFrame.F_NORMAL);
        p.add(lbl, gbc);

        gbc.gridx = 1; gbc.weightx = 0.6;
        p.add(slider, gbc);

        gbc.gridx = 2; gbc.weightx = 0.15;
        lblVal.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblVal.setForeground(MainFrame.AZUL_IA);
        lblVal.setPreferredSize(new Dimension(80, 20));
        p.add(lblVal, gbc);
    }

    private JPanel criarExplicacaoMath() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(new Color(240, 248, 240));
        p.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(MainFrame.BORDA),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)));

        JLabel t = new JLabel("📐 Como Funciona a Regressão Linear?");
        t.setFont(MainFrame.F_SUBTIT); t.setForeground(MainFrame.VERDE_ESCURO);
        t.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        p.add(t, BorderLayout.NORTH);

        String texto =
            "Regressão Linear Múltipla:\n\n" +
            "  preço = β₀ + β₁·área + β₂·quartos\n" +
            "         + β₃·banheiros + β₄·idade\n" +
            "         + β₅·distância\n\n" +
            "Coeficientes calculados por OLS:\n" +
            "  β = (XᵀX)⁻¹ · Xᵀy\n\n" +
            "Onde:\n" +
            "  X  = matriz de features (n×6)\n" +
            "  y  = vetor de preços (n×1)\n" +
            "  Xᵀ = transposta de X\n\n" +
            "Inversão de (XᵀX) por:\n" +
            "  Eliminação de Gauss-Jordan\n\n" +
            "Métricas de avaliação:\n" +
            "  R² = 1 - SS_res / SS_tot\n" +
            "  RMSE = √(Σ(yi-ŷi)² / n)\n" +
            "  MAE  = Σ|yi-ŷi| / n";

        JTextArea ta = new JTextArea(texto);
        ta.setFont(MainFrame.F_MONO);
        ta.setEditable(false);
        ta.setBackground(new Color(240, 248, 240));
        ta.setBorder(null);
        p.add(ta, BorderLayout.CENTER);
        return p;
    }

    private void prever() {
        if (!gestao.isModeloTreinado()) {
            try { gestao.treinarModelo(); mainFrame.atualizarTudo(); }
            catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro ao treinar: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }
        double area     = slArea.getValue();
        int    quartos  = slQuartos.getValue();
        int    banheiros= slBanheiros.getValue();
        int    idade    = slIdade.getValue();
        double distancia= slDistancia.getValue();

        double preco = gestao.prever(area, quartos, banheiros, idade, distancia);

        lblResultado.setText(String.format("%,.0f Kz", preco));
        lblFaixa.setText(String.format("%.0f m²  •  %d quartos  •  %d banheiros  •  %d anos  •  %.0f km do centro",
            area, quartos, banheiros, idade, distancia));

        // Interpretação
        String interp;
        if      (preco < 50000)  interp = "🏚️ Imóvel económico — faixa popular";
        else if (preco < 100000) interp = "🏠 Imóvel de gama média";
        else if (preco < 180000) interp = "🏡 Imóvel de gama alta";
        else                     interp = "🏰 Imóvel de luxo";
        lblInterpretacao.setText(interp);

        painelResultado.setBackground(preco < 50000 ? new Color(240, 248, 240)
            : preco < 100000 ? new Color(255, 252, 235)
            : preco < 180000 ? new Color(232, 244, 253)
            : new Color(253, 237, 237));
    }

    @Override public void atualizar() { /* atualiza automaticamente via sliders */ }
}

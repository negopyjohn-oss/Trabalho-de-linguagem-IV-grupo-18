package ui;

import model.Casa;
import service.GestaoPredicao;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.util.List;

/**
 * GraficoPanel — gráfico de dispersão desenhado com Graphics2D puro.
 * Sem bibliotecas de gráficos externas — apenas Java2D nativo!
 */
public class GraficoPanel extends JPanel implements MainFrame.Atualizavel {

    private GestaoPredicao gestao;
    private MainFrame mainFrame;
    private JComboBox<String> cbEixoX;
    private PainelGrafico painelGrafico;

    public GraficoPanel(GestaoPredicao gestao, MainFrame mainFrame) {
        this.gestao = gestao; this.mainFrame = mainFrame;
        setBackground(MainFrame.FUNDO);
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        construir();
        atualizar();
    }

    private void construir() {
        JPanel topo = new JPanel(new BorderLayout());
        topo.setBackground(MainFrame.FUNDO);

        JLabel titulo = new JLabel("📈 Gráfico de Dispersão — Dataset");
        titulo.setFont(MainFrame.F_TITULO); titulo.setForeground(MainFrame.VERDE_ESCURO);

        JPanel controles = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        controles.setBackground(MainFrame.FUNDO);
        controles.add(new JLabel("Eixo X:"));
        cbEixoX = new JComboBox<>(new String[]{"Área (m²)", "Quartos", "Banheiros", "Idade (anos)", "Distância (km)"});
        cbEixoX.setFont(MainFrame.F_NORMAL);
        cbEixoX.addActionListener(e -> painelGrafico.repaint());
        controles.add(cbEixoX);

        JButton btnTreinar = MainFrame.criarBotao("⚙️ Treinar e Mostrar Linha", MainFrame.AZUL_IA);
        btnTreinar.addActionListener(e -> {
            try { gestao.treinarModelo(); mainFrame.atualizarTudo(); }
            catch (Exception ex) { JOptionPane.showMessageDialog(this, ex.getMessage()); }
        });
        controles.add(btnTreinar);

        topo.add(titulo, BorderLayout.WEST);
        topo.add(controles, BorderLayout.EAST);
        add(topo, BorderLayout.NORTH);

        painelGrafico = new PainelGrafico();
        painelGrafico.setBorder(BorderFactory.createLineBorder(MainFrame.BORDA));
        add(painelGrafico, BorderLayout.CENTER);

        // Legenda
        JPanel legenda = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 5));
        legenda.setBackground(MainFrame.FUNDO);
        legenda.add(criarItemLegenda("● Preço Real", MainFrame.AZUL_IA));
        legenda.add(criarItemLegenda("● Preço Previsto", MainFrame.LARANJA));
        legenda.add(criarItemLegenda("— Linha de Regressão", MainFrame.VERMELHO));
        add(legenda, BorderLayout.SOUTH);
    }

    private JLabel criarItemLegenda(String texto, Color cor) {
        JLabel l = new JLabel(texto);
        l.setFont(MainFrame.F_NORMAL);
        l.setForeground(cor);
        return l;
    }

    @Override public void atualizar() { if (painelGrafico != null) painelGrafico.repaint(); }

    // ─────────────────────────────────────────────────────────────────
    // Painel de desenho com Graphics2D
    // ─────────────────────────────────────────────────────────────────
    class PainelGrafico extends JPanel {

        private static final int MARGEM = 60;

        public PainelGrafico() {
            setBackground(Color.WHITE);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

            List<Casa> casas = gestao.getDataset();
            if (casas.isEmpty()) {
                desenharMsgVazia(g2);
                g2.dispose(); return;
            }

            int W = getWidth(), H = getHeight();
            int areaW = W - 2 * MARGEM, areaH = H - 2 * MARGEM;

            // Determinar eixo X selecionado
            int eixo = cbEixoX.getSelectedIndex();
            double[] xs = casas.stream().mapToDouble(c -> getValorX(c, eixo)).toArray();
            double[] ys = casas.stream().mapToDouble(Casa::getPrecoReal).toArray();

            double minX = min(xs), maxX = max(xs);
            double minY = 0,       maxY = max(ys) * 1.1;
            if (minX == maxX) { minX -= 1; maxX += 1; }

            // ── Fundo e grade ───────────────────────────────────────
            g2.setColor(new Color(248, 252, 248));
            g2.fillRect(MARGEM, MARGEM, areaW, areaH);

            g2.setColor(new Color(220, 235, 220));
            g2.setStroke(new BasicStroke(1, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[]{4}, 0));
            for (int i = 1; i <= 5; i++) {
                int gy = MARGEM + (int)(areaH * i / 5.0);
                g2.drawLine(MARGEM, gy, MARGEM + areaW, gy);
                int gx = MARGEM + (int)(areaW * i / 5.0);
                g2.drawLine(gx, MARGEM, gx, MARGEM + areaH);
            }

            // ── Eixos ───────────────────────────────────────────────
            g2.setColor(MainFrame.TEXTO);
            g2.setStroke(new BasicStroke(2));
            g2.drawLine(MARGEM, MARGEM, MARGEM, MARGEM + areaH);
            g2.drawLine(MARGEM, MARGEM + areaH, MARGEM + areaW, MARGEM + areaH);

            // ── Labels dos eixos ────────────────────────────────────
            g2.setFont(new Font("Segoe UI", Font.PLAIN, 10));
            g2.setColor(MainFrame.TEXTO_CLARO);
            for (int i = 0; i <= 5; i++) {
                double vY = minY + (maxY - minY) * (5 - i) / 5.0;
                int py = MARGEM + (int)(areaH * i / 5.0);
                g2.drawString(String.format("%,.0f Kz", vY), 2, py + 4);

                double vX = minX + (maxX - minX) * i / 5.0;
                int px = MARGEM + (int)(areaW * i / 5.0);
                g2.drawString(String.format("%.1f", vX), px - 15, MARGEM + areaH + 14);
            }

            // Títulos eixos
            g2.setFont(new Font("Segoe UI", Font.BOLD, 12));
            g2.setColor(MainFrame.TEXTO);
            g2.drawString("Preço (Kz)", 5, MARGEM - 8);
            String[] nomes = {"Área (m²)", "Quartos", "Banheiros", "Idade (anos)", "Distância (km)"};
            g2.drawString(nomes[eixo], MARGEM + areaW / 2 - 30, H - 8);

            // ── Linha de regressão (usando pontos extremos) ─────────
            if (gestao.isModeloTreinado()) {
                // Linha entre ponto mínimo e máximo do eixo X
                g2.setColor(MainFrame.VERMELHO);
                g2.setStroke(new BasicStroke(2.5f));

                // Calcular y previsto para xMin e xMax usando o coef da variável
                double yPmin = preverSimplificado(casas, eixo, minX);
                double yPmax = preverSimplificado(casas, eixo, maxX);

                int x1 = toPixelX(minX, minX, maxX, MARGEM, areaW);
                int y1 = toPixelY(yPmin, minY, maxY, MARGEM, areaH);
                int x2 = toPixelX(maxX, minX, maxX, MARGEM, areaW);
                int y2 = toPixelY(yPmax, minY, maxY, MARGEM, areaH);
                g2.drawLine(x1, y1, x2, y2);
            }

            // ── Pontos: preço real (azul) ────────────────────────────
            for (int i = 0; i < casas.size(); i++) {
                int px = toPixelX(xs[i], minX, maxX, MARGEM, areaW);
                int py = toPixelY(ys[i], minY, maxY, MARGEM, areaH);

                // Sombra
                g2.setColor(new Color(0,0,0,30));
                g2.fillOval(px - 5, py - 3, 12, 12);

                // Ponto real
                g2.setColor(MainFrame.AZUL_IA);
                g2.setStroke(new BasicStroke(1));
                g2.fillOval(px - 5, py - 5, 10, 10);
                g2.setColor(Color.WHITE);
                g2.drawOval(px - 5, py - 5, 10, 10);

                // Ponto previsto (laranja) — se treinado
                Casa c = casas.get(i);
                if (gestao.isModeloTreinado() && c.getPrecoPredicao() > 0) {
                    int pyP = toPixelY(c.getPrecoPredicao(), minY, maxY, MARGEM, areaH);
                    g2.setColor(MainFrame.LARANJA);
                    g2.fillOval(px - 4, pyP - 4, 8, 8);

                    // Linha ligando real ao previsto
                    g2.setColor(new Color(150, 150, 150, 80));
                    g2.setStroke(new BasicStroke(1, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[]{3}, 0));
                    g2.drawLine(px, py, px, pyP);
                }
            }

            // ── Título do gráfico ────────────────────────────────────
            g2.setFont(new Font("Segoe UI", Font.BOLD, 13));
            g2.setColor(MainFrame.VERDE_ESCURO);
            g2.drawString("Dispersão: " + new String[]{"Área","Quartos","Banheiros","Idade","Distância"}[eixo] + " × Preço", MARGEM + 10, MARGEM - 10);

            if (gestao.isModeloTreinado()) {
                g2.setFont(new Font("Segoe UI", Font.PLAIN, 11));
                g2.setColor(MainFrame.VERMELHO);
                g2.drawString("R² = " + String.format("%.4f", gestao.getModelo().getR2()), W - 110, MARGEM - 10);
            }

            g2.dispose();
        }

        private double getValorX(Casa c, int eixo) {
            return switch (eixo) {
                case 0 -> c.getAreaM2();
                case 1 -> c.getQuartos();
                case 2 -> c.getBanheiros();
                case 3 -> c.getIdadeAnos();
                case 4 -> c.getDistanciaCentroKm();
                default -> c.getAreaM2();
            };
        }

        private double preverSimplificado(List<Casa> casas, int eixo, double xVal) {
            // Usa médias para todas as outras variáveis
            double mArea = casas.stream().mapToDouble(Casa::getAreaM2).average().orElse(80);
            int    mQua  = (int) casas.stream().mapToDouble(c -> c.getQuartos()).average().orElse(2);
            int    mBan  = (int) casas.stream().mapToDouble(c -> c.getBanheiros()).average().orElse(2);
            int    mIda  = (int) casas.stream().mapToDouble(c -> c.getIdadeAnos()).average().orElse(5);
            double mDis  = casas.stream().mapToDouble(Casa::getDistanciaCentroKm).average().orElse(8);

            return switch (eixo) {
                case 0 -> gestao.getModelo().prever(xVal, mQua, mBan, mIda, mDis);
                case 1 -> gestao.getModelo().prever(mArea, (int)xVal, mBan, mIda, mDis);
                case 2 -> gestao.getModelo().prever(mArea, mQua, (int)xVal, mIda, mDis);
                case 3 -> gestao.getModelo().prever(mArea, mQua, mBan, (int)xVal, mDis);
                case 4 -> gestao.getModelo().prever(mArea, mQua, mBan, mIda, xVal);
                default -> 0;
            };
        }

        private int toPixelX(double v, double min, double max, int margem, int w) {
            return margem + (int)((v - min) / (max - min) * w);
        }
        private int toPixelY(double v, double min, double max, int margem, int h) {
            double clamped = Math.max(min, Math.min(max, v));
            return margem + h - (int)((clamped - min) / (max - min) * h);
        }

        private void desenharMsgVazia(Graphics2D g2) {
            g2.setColor(MainFrame.TEXTO_CLARO);
            g2.setFont(new Font("Segoe UI", Font.PLAIN, 16));
            g2.drawString("Dataset vazio.", getWidth()/2 - 50, getHeight()/2);
        }

        private double min(double[] a) { double m = a[0]; for (double x : a) if (x < m) m = x; return m; }
        private double max(double[] a) { double m = a[0]; for (double x : a) if (x > m) m = x; return m; }
    }
}

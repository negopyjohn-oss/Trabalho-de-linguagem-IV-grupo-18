package ui;

import model.ResultadoRegressao;
import service.GestaoPredicao;

import javax.swing.*;
import java.awt.*;
import java.util.Map;

public class DashboardPanel extends JPanel implements MainFrame.Atualizavel {

    private GestaoPredicao gestao;
    private MainFrame      mainFrame;
    private JPanel         painelCards, painelMetricas, painelCorrelacoes;

    public DashboardPanel(GestaoPredicao gestao, MainFrame mainFrame) {
        this.gestao = gestao; this.mainFrame = mainFrame;
        setBackground(MainFrame.FUNDO);
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        construir();
        atualizar();
    }

    private void construir() {
        JLabel titulo = new JLabel("🏠 Dashboard — Visão Geral do Sistema");
        titulo.setFont(MainFrame.F_TITULO);
        titulo.setForeground(MainFrame.VERDE_ESCURO);
        titulo.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        add(titulo, BorderLayout.NORTH);

        JPanel centro = new JPanel(new GridLayout(1, 2, 15, 0));
        centro.setBackground(MainFrame.FUNDO);

        // Coluna esquerda
        JPanel esq = new JPanel();
        esq.setLayout(new BoxLayout(esq, BoxLayout.Y_AXIS));
        esq.setBackground(MainFrame.FUNDO);

        painelCards = new JPanel(new GridLayout(2, 4, 10, 10));
        painelCards.setBackground(MainFrame.FUNDO);
        painelCards.setMaximumSize(new Dimension(Integer.MAX_VALUE, 130));
        esq.add(painelCards);
        esq.add(Box.createVerticalStrut(15));

        painelCorrelacoes = new JPanel(new BorderLayout());
        painelCorrelacoes.setBackground(MainFrame.CARTAO);
        esq.add(painelCorrelacoes);

        // Coluna direita — métricas do modelo
        painelMetricas = new JPanel(new BorderLayout());
        painelMetricas.setBackground(MainFrame.CARTAO);

        centro.add(esq);
        centro.add(painelMetricas);

        JScrollPane scroll = new JScrollPane(centro);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(MainFrame.FUNDO);
        add(scroll, BorderLayout.CENTER);

        // Botão treinar inicial
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        btnPanel.setBackground(MainFrame.FUNDO);
        JButton btn = MainFrame.criarBotao("⚙️ Treinar Modelo de Regressão Agora", MainFrame.AZUL_IA);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.addActionListener(e -> {
            try {
                gestao.treinarModelo();
                mainFrame.atualizarTudo();
                JOptionPane.showMessageDialog(this, "✅ Modelo treinado!\nR² = " +
                    String.format("%.4f", gestao.getModelo().getR2()), "OK", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });
        btnPanel.add(btn);
        add(btnPanel, BorderLayout.SOUTH);
    }

    @Override
    public void atualizar() {
        atualizarCards();
        atualizarMetricas();
        atualizarCorrelacoes();
        revalidate(); repaint();
    }

    private void atualizarCards() {
        painelCards.removeAll();
        Map<String, Double> stats = gestao.getEstatisticas();
        String[] icones = {"🏠","📐","📐","📐","💰","💰","💰","📍"};
        Color[]  cores  = {MainFrame.VERDE_ESCURO, MainFrame.VERDE_MEDIO, MainFrame.VERDE_MEDIO,
                           MainFrame.AZUL_IA, MainFrame.LARANJA, MainFrame.VERDE_ESCURO,
                           MainFrame.VERMELHO, new Color(106, 27, 154)};
        int i = 0;
        for (Map.Entry<String, Double> e : stats.entrySet()) {
            String val = e.getKey().contains("Kz")
                ? String.format("%,.0f Kz", e.getValue())
                : e.getKey().contains("Casas")
                    ? String.format("%,.0f", e.getValue())
                    : String.format("%.1f", e.getValue());
            painelCards.add(criarCard(icones[i % icones.length], e.getKey(), val, cores[i % cores.length]));
            i++;
        }
    }

    private JPanel criarCard(String icone, String titulo, String valor, Color cor) {
        JPanel c = new JPanel();
        c.setLayout(new BoxLayout(c, BoxLayout.Y_AXIS));
        c.setBackground(MainFrame.CARTAO);
        c.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 4, 0, 0, cor),
            BorderFactory.createEmptyBorder(10, 12, 10, 12)));
        JLabel li = new JLabel(icone); li.setFont(new Font("Segoe UI", Font.PLAIN, 20)); li.setAlignmentX(LEFT_ALIGNMENT);
        JLabel lv = new JLabel(valor); lv.setFont(new Font("Segoe UI", Font.BOLD, 18)); lv.setForeground(cor); lv.setAlignmentX(LEFT_ALIGNMENT);
        JLabel lt = new JLabel("<html><small>" + titulo + "</small></html>"); lt.setForeground(MainFrame.TEXTO_CLARO); lt.setAlignmentX(LEFT_ALIGNMENT);
        c.add(li); c.add(Box.createVerticalStrut(3)); c.add(lv); c.add(lt);
        return c;
    }

    private void atualizarMetricas() {
        painelMetricas.removeAll();
        painelMetricas.setBackground(MainFrame.CARTAO);
        painelMetricas.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(MainFrame.BORDA),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)));

        JLabel titulo = new JLabel("📐 Métricas do Modelo de IA");
        titulo.setFont(MainFrame.F_SUBTIT);
        titulo.setForeground(MainFrame.AZUL_IA);
        titulo.setBorder(BorderFactory.createEmptyBorder(0, 0, 12, 0));
        painelMetricas.add(titulo, BorderLayout.NORTH);

        JPanel corpo = new JPanel();
        corpo.setLayout(new BoxLayout(corpo, BoxLayout.Y_AXIS));
        corpo.setBackground(MainFrame.CARTAO);

        if (!gestao.isModeloTreinado()) {
            JLabel aviso = new JLabel("<html><center><b>Modelo não treinado ainda.</b><br>Clique em <i>Treinar Modelo</i> para começar.</center></html>");
            aviso.setFont(MainFrame.F_NORMAL);
            aviso.setForeground(MainFrame.TEXTO_CLARO);
            aviso.setHorizontalAlignment(SwingConstants.CENTER);
            corpo.add(aviso);
        } else {
            ResultadoRegressao m = gestao.getModelo();
            adicionarMetrica(corpo, "R² (Coef. Determinação)",
                String.format("%.4f — %s", m.getR2(), m.classificacaoR2()),
                getCorR2(m.getR2()));
            adicionarBarra(corpo, m.getR2());
            adicionarMetrica(corpo, "RMSE",         String.format("%,.2f Kz",  m.getRmse()), MainFrame.LARANJA);
            adicionarMetrica(corpo, "MAE",          String.format("%,.2f Kz",  m.getMae()),  MainFrame.AZUL_IA);
            adicionarMetrica(corpo, "MAPE",         String.format("%.2f%%",  m.getMape()), MainFrame.VERMELHO);
            adicionarMetrica(corpo, "Amostras",     String.valueOf(m.getNAmostras()),       MainFrame.VERDE_ESCURO);

            corpo.add(Box.createVerticalStrut(15));
            JLabel eq = new JLabel("<html><b>Equação do Modelo:</b></html>");
            eq.setFont(MainFrame.F_NORMAL);
            corpo.add(eq);
            corpo.add(Box.createVerticalStrut(5));
            JTextArea txt = new JTextArea(String.format(
                "preço = %.0f\n  + %.2f × área\n  + %.0f × quartos\n" +
                "  + %.0f × banheiros\n  + (%.0f) × idade\n  + (%.0f) × distância",
                m.getIntercepto(), m.getCoefArea(), m.getCoefQuartos(),
                m.getCoefBanheiros(), m.getCoefIdade(), m.getCoefDistancia()));
            txt.setFont(MainFrame.F_MONO);
            txt.setEditable(false);
            txt.setBackground(new Color(245, 250, 245));
            txt.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
            corpo.add(txt);
        }
        painelMetricas.add(corpo, BorderLayout.CENTER);
    }

    private void adicionarMetrica(JPanel p, String nome, String valor, Color cor) {
        JPanel linha = new JPanel(new BorderLayout());
        linha.setBackground(MainFrame.CARTAO);
        linha.setBorder(BorderFactory.createEmptyBorder(5, 0, 5, 0));
        JLabel ln = new JLabel(nome + ": "); ln.setFont(MainFrame.F_NORMAL); ln.setForeground(MainFrame.TEXTO_CLARO);
        JLabel lv = new JLabel(valor);       lv.setFont(new Font("Segoe UI", Font.BOLD, 13)); lv.setForeground(cor);
        linha.add(ln, BorderLayout.WEST);
        linha.add(lv, BorderLayout.EAST);
        linha.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        p.add(linha);
    }

    private void adicionarBarra(JPanel p, double r2) {
        JProgressBar bar = new JProgressBar(0, 100);
        bar.setValue((int)(r2 * 100));
        bar.setStringPainted(true);
        bar.setString(String.format("%.1f%%", r2 * 100));
        bar.setForeground(getCorR2(r2));
        bar.setBackground(new Color(230, 230, 230));
        bar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 22));
        p.add(bar);
    }

    private void atualizarCorrelacoes() {
        painelCorrelacoes.removeAll();
        painelCorrelacoes.setBackground(MainFrame.CARTAO);
        painelCorrelacoes.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(MainFrame.BORDA),
            BorderFactory.createEmptyBorder(12, 15, 12, 15)));

        JLabel titulo = new JLabel("🔗 Correlação de Pearson com Preço");
        titulo.setFont(MainFrame.F_SUBTIT); titulo.setForeground(MainFrame.VERDE_ESCURO);
        titulo.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        painelCorrelacoes.add(titulo, BorderLayout.NORTH);

        JPanel barras = new JPanel(new GridLayout(0, 1, 0, 8));
        barras.setBackground(MainFrame.CARTAO);

        for (Map.Entry<String, Double> e : gestao.getCorrelacoes().entrySet()) {
            double r = e.getValue();
            JPanel linha = new JPanel(new BorderLayout(10, 0));
            linha.setBackground(MainFrame.CARTAO);
            JLabel lbl = new JLabel(e.getKey());
            lbl.setFont(MainFrame.F_PEQUENA);
            lbl.setPreferredSize(new Dimension(130, 18));
            JProgressBar bar = new JProgressBar(-100, 100);
            bar.setValue((int)(r * 100));
            Color cor = r > 0 ? MainFrame.VERDE_MEDIO : MainFrame.VERMELHO;
            bar.setForeground(cor);
            bar.setStringPainted(true);
            bar.setString(String.format("r = %.3f", r));
            bar.setBackground(new Color(230, 230, 230));
            linha.add(lbl, BorderLayout.WEST);
            linha.add(bar, BorderLayout.CENTER);
            barras.add(linha);
        }
        painelCorrelacoes.add(barras, BorderLayout.CENTER);
    }

    private Color getCorR2(double r2) {
        if (r2 >= 0.9) return MainFrame.VERDE_ESCURO;
        if (r2 >= 0.7) return MainFrame.LARANJA;
        return MainFrame.VERMELHO;
    }
}

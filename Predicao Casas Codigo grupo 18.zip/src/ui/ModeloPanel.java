package ui;

import model.ResultadoRegressao;
import service.GestaoPredicao;

import javax.swing.*;
import java.awt.*;

public class ModeloPanel extends JPanel implements MainFrame.Atualizavel {

    private GestaoPredicao gestao;
    private MainFrame mainFrame;
    private JTextArea txtModelo;
    private JPanel    painelCoef;

    public ModeloPanel(GestaoPredicao gestao, MainFrame mainFrame) {
        this.gestao = gestao; this.mainFrame = mainFrame;
        setBackground(MainFrame.FUNDO);
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        construir();
        atualizar();
    }

    private void construir() {
        JLabel titulo = new JLabel("📐 Detalhes do Modelo Matemático");
        titulo.setFont(MainFrame.F_TITULO); titulo.setForeground(MainFrame.VERDE_ESCURO);
        titulo.setBorder(BorderFactory.createEmptyBorder(0, 0, 12, 0));
        add(titulo, BorderLayout.NORTH);

        JPanel centro = new JPanel(new GridLayout(1, 2, 15, 0));
        centro.setBackground(MainFrame.FUNDO);

        // Coluna esquerda — coeficientes
        painelCoef = new JPanel();
        painelCoef.setLayout(new BoxLayout(painelCoef, BoxLayout.Y_AXIS));
        painelCoef.setBackground(MainFrame.CARTAO);
        painelCoef.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(MainFrame.BORDA),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)));

        // Coluna direita — explicação matemática detalhada
        txtModelo = new JTextArea();
        txtModelo.setFont(MainFrame.F_MONO);
        txtModelo.setEditable(false);
        txtModelo.setBackground(new Color(245, 250, 245));
        txtModelo.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        txtModelo.setLineWrap(true);
        txtModelo.setWrapStyleWord(true);

        JScrollPane scrollEsq = new JScrollPane(painelCoef);
        scrollEsq.setBorder(BorderFactory.createLineBorder(MainFrame.BORDA));
        JScrollPane scrollDir = new JScrollPane(txtModelo);
        scrollDir.setBorder(BorderFactory.createLineBorder(MainFrame.BORDA));

        centro.add(scrollEsq);
        centro.add(scrollDir);
        add(centro, BorderLayout.CENTER);

        JButton btnTreinar = MainFrame.criarBotao("⚙️ Treinar / Retreinar Modelo", MainFrame.AZUL_IA);
        btnTreinar.addActionListener(e -> {
            try {
                gestao.treinarModelo();
                mainFrame.atualizarTudo();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });
        JPanel btn = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btn.setBackground(MainFrame.FUNDO);
        btn.add(btnTreinar);
        add(btn, BorderLayout.SOUTH);
    }

    @Override
    public void atualizar() {
        painelCoef.removeAll();
        JLabel hdr = new JLabel("⚙️ Coeficientes do Modelo (β)");
        hdr.setFont(MainFrame.F_SUBTIT); hdr.setForeground(MainFrame.AZUL_IA);
        hdr.setBorder(BorderFactory.createEmptyBorder(0, 0, 12, 0));
        hdr.setAlignmentX(Component.LEFT_ALIGNMENT);
        painelCoef.add(hdr);

        if (!gestao.isModeloTreinado()) {
            JLabel aviso = new JLabel("Modelo não treinado. Clique em Treinar.");
            aviso.setFont(MainFrame.F_NORMAL); aviso.setForeground(MainFrame.TEXTO_CLARO);
            aviso.setAlignmentX(Component.LEFT_ALIGNMENT);
            painelCoef.add(aviso);
            txtModelo.setText(getTextoExplicacao(null));
        } else {
            ResultadoRegressao m = gestao.getModelo();

            String[][] coefs = {
                {"β₀  Intercepto",     String.format("%,.2f Kz", m.getIntercepto()),   "Preço base quando tudo é zero"},
                {"β₁  Área (m²)",      String.format("+%.2f Kz/m²", m.getCoefArea()),  "Cada m² adiciona este valor"},
                {"β₂  Quartos",        String.format("+%,.2f Kz/q", m.getCoefQuartos()),"Valor por quarto adicional"},
                {"β₃  Banheiros",      String.format("+%,.2f Kz/b", m.getCoefBanheiros()),"Valor por banheiro adicional"},
                {"β₄  Idade (anos)",   String.format("%,.2f Kz/ano", m.getCoefIdade()), "Depreciação anual (negativo)"},
                {"β₅  Distância (km)", String.format("%,.2f Kz/km", m.getCoefDistancia()),"Desconto por km do centro"},
            };

            for (String[] c : coefs) {
                JPanel linha = new JPanel(new BorderLayout(8, 0));
                linha.setBackground(MainFrame.CARTAO);
                linha.setMaximumSize(new Dimension(Integer.MAX_VALUE, 55));
                linha.setAlignmentX(Component.LEFT_ALIGNMENT);
                linha.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, MainFrame.BORDA));

                JLabel lNome = new JLabel(c[0]);
                lNome.setFont(new Font("Courier New", Font.BOLD, 12));
                lNome.setForeground(MainFrame.VERDE_ESCURO);
                lNome.setPreferredSize(new Dimension(170, 20));

                double val = Double.parseDouble(c[1].replaceAll("[^0-9.\\-]","").replace(",",""));
                JLabel lVal = new JLabel(c[1]);
                lVal.setFont(new Font("Segoe UI", Font.BOLD, 13));
                lVal.setForeground(val >= 0 ? MainFrame.VERDE_ESCURO : MainFrame.VERMELHO);

                JLabel lDesc = new JLabel("<html><small><i>" + c[2] + "</i></small></html>");
                lDesc.setFont(MainFrame.F_PEQUENA);
                lDesc.setForeground(MainFrame.TEXTO_CLARO);

                JPanel esq = new JPanel(new GridLayout(2,1));
                esq.setOpaque(false);
                esq.add(lNome); esq.add(lDesc);

                linha.add(esq, BorderLayout.CENTER);
                linha.add(lVal, BorderLayout.EAST);
                linha.setBorder(BorderFactory.createEmptyBorder(8, 5, 8, 5));
                painelCoef.add(linha);
            }

            // Métricas
            painelCoef.add(Box.createVerticalStrut(15));
            JLabel hdr2 = new JLabel("📊 Métricas de Avaliação");
            hdr2.setFont(MainFrame.F_SUBTIT); hdr2.setForeground(MainFrame.LARANJA);
            hdr2.setAlignmentX(Component.LEFT_ALIGNMENT);
            painelCoef.add(hdr2);
            painelCoef.add(Box.createVerticalStrut(8));

            adicionarMetricaSimples(painelCoef, "R²",   String.format("%.6f  (%s)", m.getR2(), m.classificacaoR2()), MainFrame.VERDE_ESCURO);
            adicionarMetricaSimples(painelCoef, "RMSE", String.format("%,.2f Kz", m.getRmse()), MainFrame.LARANJA);
            adicionarMetricaSimples(painelCoef, "MAE",  String.format("%,.2f Kz", m.getMae()),  MainFrame.AZUL_IA);
            adicionarMetricaSimples(painelCoef, "MAPE", String.format("%.2f%%", m.getMape()), MainFrame.VERMELHO);
            adicionarMetricaSimples(painelCoef, "n",    String.valueOf(m.getNAmostras()),       MainFrame.TEXTO);

            txtModelo.setText(getTextoExplicacao(m));
        }

        painelCoef.revalidate(); painelCoef.repaint();
        revalidate(); repaint();
    }

    private void adicionarMetricaSimples(JPanel p, String nome, String valor, Color cor) {
        JPanel l = new JPanel(new BorderLayout());
        l.setBackground(MainFrame.CARTAO); l.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel ln = new JLabel(nome + ":  "); ln.setFont(MainFrame.F_NORMAL); ln.setForeground(MainFrame.TEXTO_CLARO);
        JLabel lv = new JLabel(valor); lv.setFont(new Font("Segoe UI", Font.BOLD, 13)); lv.setForeground(cor);
        l.add(ln, BorderLayout.WEST); l.add(lv, BorderLayout.EAST);
        p.add(l);
    }

    private String getTextoExplicacao(ResultadoRegressao m) {
        StringBuilder sb = new StringBuilder();
        sb.append("══════════════════════════════════════════════\n");
        sb.append("  REGRESSÃO LINEAR MÚLTIPLA — IMPLEMENTAÇÃO\n");
        sb.append("══════════════════════════════════════════════\n\n");
        sb.append("MODELO:\n");
        sb.append("  ŷ = β₀ + β₁x₁ + β₂x₂ + β₃x₃ + β₄x₄ + β₅x₅\n\n");
        sb.append("VARIÁVEIS:\n");
        sb.append("  x₁ = Área (m²)\n");
        sb.append("  x₂ = Número de Quartos\n");
        sb.append("  x₃ = Número de Banheiros\n");
        sb.append("  x₄ = Idade do Imóvel (anos)\n");
        sb.append("  x₅ = Distância ao Centro (km)\n\n");
        sb.append("MÉTODO OLS (Mínimos Quadrados Ordinários):\n");
        sb.append("  Minimizar: Σ(yi - ŷi)²\n");
        sb.append("  Solução analítica: β = (XᵀX)⁻¹ · Xᵀy\n\n");
        sb.append("PASSOS DA IMPLEMENTAÇÃO:\n");
        sb.append("  1. Montar matriz X (n×6) com coluna de 1s\n");
        sb.append("  2. Calcular XᵀX (produto matricial)\n");
        sb.append("  3. Calcular Xᵀy (produto matriz-vetor)\n");
        sb.append("  4. Inverter XᵀX (Eliminação Gauss-Jordan)\n");
        sb.append("  5. β = (XᵀX)⁻¹ · Xᵀy\n\n");
        sb.append("INVERSÃO GAUSS-JORDAN:\n");
        sb.append("  [A | I] → operações de linha → [I | A⁻¹]\n");
        sb.append("  - Pivotamento parcial para estabilidade\n");
        sb.append("  - Normalização da linha do pivô\n");
        sb.append("  - Eliminação em todas as outras linhas\n\n");
        sb.append("MÉTRICAS:\n");
        sb.append("  R² = 1 - SS_res / SS_tot\n");
        sb.append("     SS_res = Σ(yi - ŷi)²\n");
        sb.append("     SS_tot = Σ(yi - ȳ)²\n\n");
        sb.append("  RMSE = √(Σ(yi-ŷi)² / n)\n");
        sb.append("  MAE  = Σ|yi-ŷi| / n\n");
        sb.append("  MAPE = Σ(|yi-ŷi|/yi) / n × 100\n\n");
        sb.append("CORRELAÇÃO DE PEARSON:\n");
        sb.append("  r = Σ(xi-x̄)(yi-ȳ) / √[Σ(xi-x̄)² · Σ(yi-ȳ)²]\n\n");

        if (m != null) {
            sb.append("══════════════════════════════════════════════\n");
            sb.append("  EQUAÇÃO DO MODELO TREINADO:\n");
            sb.append("══════════════════════════════════════════════\n");
            sb.append(String.format("  preço = %,.2f\n", m.getIntercepto()));
            sb.append(String.format("    + %,.4f × área\n", m.getCoefArea()));
            sb.append(String.format("    + %,.4f × quartos\n", m.getCoefQuartos()));
            sb.append(String.format("    + %,.4f × banheiros\n", m.getCoefBanheiros()));
            sb.append(String.format("    + (%,.4f) × idade\n", m.getCoefIdade()));
            sb.append(String.format("    + (%,.4f) × distância\n\n", m.getCoefDistancia()));
            sb.append(String.format("  R²   = %.6f (%s)\n", m.getR2(), m.classificacaoR2()));
            sb.append(String.format("  RMSE = %,.2f Kz\n", m.getRmse()));
            sb.append(String.format("  MAE  = %,.2f Kz\n", m.getMae()));
            sb.append(String.format("  MAPE = %.2f%%\n", m.getMape()));
        }
        return sb.toString();
    }
}

package model;

/**
 * Classe ResultadoRegressao — armazena os coeficientes e métricas do modelo.
 *
 * REGRESSÃO LINEAR MÚLTIPLA:
 *   preço = β0 + β1*área + β2*quartos + β3*banheiros + β4*idade + β5*distância
 *
 * Coeficientes calculados pelo método dos Mínimos Quadrados Ordinários (OLS):
 *   β = (XᵀX)⁻¹ Xᵀy
 */
public class ResultadoRegressao {

    // Coeficientes do modelo
    private double intercepto;       // β0
    private double coefArea;         // β1 — influência da área
    private double coefQuartos;      // β2 — influência dos quartos
    private double coefBanheiros;    // β3 — influência dos banheiros
    private double coefIdade;        // β4 — influência da idade (negativo)
    private double coefDistancia;    // β5 — influência da distância (negativo)

    // Métricas de avaliação do modelo
    private double r2;               // Coeficiente de determinação R²
    private double rmsE;             // Root Mean Square Error (RMSE)
    private double maeE;             // Mean Absolute Error (MAE)
    private double mapeE;            // Mean Absolute Percentage Error (MAPE)
    private int    nAmostras;        // número de amostras usadas no treino

    // ============================================================
    // GETTERS E SETTERS
    // ============================================================
    public double getIntercepto()      { return intercepto; }
    public void   setIntercepto(double v) { intercepto = v; }

    public double getCoefArea()        { return coefArea; }
    public void   setCoefArea(double v){ coefArea = v; }

    public double getCoefQuartos()     { return coefQuartos; }
    public void   setCoefQuartos(double v){ coefQuartos = v; }

    public double getCoefBanheiros()   { return coefBanheiros; }
    public void   setCoefBanheiros(double v){ coefBanheiros = v; }

    public double getCoefIdade()       { return coefIdade; }
    public void   setCoefIdade(double v){ coefIdade = v; }

    public double getCoefDistancia()   { return coefDistancia; }
    public void   setCoefDistancia(double v){ coefDistancia = v; }

    public double getR2()              { return r2; }
    public void   setR2(double v)      { r2 = v; }

    public double getRmse()            { return rmsE; }
    public void   setRmse(double v)    { rmsE = v; }

    public double getMae()             { return maeE; }
    public void   setMae(double v)     { maeE = v; }

    public double getMape()            { return mapeE; }
    public void   setMape(double v)    { mapeE = v; }

    public int    getNAmostras()       { return nAmostras; }
    public void   setNAmostras(int v)  { nAmostras = v; }

    /**
     * Prediz o preço de uma nova casa usando os coeficientes do modelo.
     * fórmula: preço = β0 + β1*área + β2*quartos + β3*banheiros + β4*idade + β5*distância
     */
    public double prever(double area, int quartos, int banheiros,
                         int idade, double distancia) {
        double pred = intercepto
                + coefArea        * area
                + coefQuartos     * quartos
                + coefBanheiros   * banheiros
                + coefIdade       * idade
                + coefDistancia   * distancia;
        return Math.max(pred, 0); // preço nunca negativo
    }

    /** Interpreta a qualidade do modelo pelo R² */
    public String classificacaoR2() {
        if (r2 >= 0.90) return "Excelente";
        if (r2 >= 0.75) return "Bom";
        if (r2 >= 0.50) return "Moderado";
        return "Fraco";
    }

    @Override
    public String toString() {
        return String.format(
            "Modelo: preço = %.2f + %.2f*área + %.2f*quartos + %.2f*banheiros + %.2f*idade + %.2f*dist | R²=%.4f",
            intercepto, coefArea, coefQuartos, coefBanheiros, coefIdade, coefDistancia, r2);
    }
}

package model;

/**
 * Classe Casa — representa um imóvel com características e preço.
 *
 * CONCEITOS DE POO:
 * - Encapsulamento: atributos privados com getters/setters
 * - Abstração: modela o conceito real de uma casa
 */
public class Casa {

    // ============================================================
    // ATRIBUTOS (variáveis independentes para a regressão)
    // ============================================================
    private String id;
    private double areaM2;           // área em m²
    private int    quartos;          // número de quartos
    private int    banheiros;        // número de banheiros
    private int    idadeAnos;        // idade do imóvel em anos
    private double distanciaCentroKm; // distância ao centro (km)
    private double precoReal;        // preço real (kz ou usd)
    private double precoPredicao;    // preço previsto pelo modelo

    // ============================================================
    // CONSTRUTORES
    // ============================================================
    public Casa(String id, double areaM2, int quartos, int banheiros,
                int idadeAnos, double distanciaCentroKm, double precoReal) {
        this.id                = id;
        this.areaM2            = areaM2;
        this.quartos           = quartos;
        this.banheiros         = banheiros;
        this.idadeAnos         = idadeAnos;
        this.distanciaCentroKm = distanciaCentroKm;
        this.precoReal         = precoReal;
        this.precoPredicao     = 0.0;
    }

    public Casa() {}

    // ============================================================
    // GETTERS E SETTERS
    // ============================================================
    public String getId()                          { return id; }
    public void   setId(String id)                 { this.id = id; }

    public double getAreaM2()                      { return areaM2; }
    public void   setAreaM2(double areaM2)         { this.areaM2 = areaM2; }

    public int    getQuartos()                     { return quartos; }
    public void   setQuartos(int quartos)          { this.quartos = quartos; }

    public int    getBanheiros()                   { return banheiros; }
    public void   setBanheiros(int banheiros)      { this.banheiros = banheiros; }

    public int    getIdadeAnos()                   { return idadeAnos; }
    public void   setIdadeAnos(int idadeAnos)      { this.idadeAnos = idadeAnos; }

    public double getDistanciaCentroKm()           { return distanciaCentroKm; }
    public void   setDistanciaCentroKm(double d)   { this.distanciaCentroKm = d; }

    public double getPrecoReal()                   { return precoReal; }
    public void   setPrecoReal(double precoReal)   { this.precoReal = precoReal; }

    public double getPrecoPredicao()               { return precoPredicao; }
    public void   setPrecoPredicao(double p)       { this.precoPredicao = p; }

    /** Erro absoluto entre preço real e predito */
    public double getErroAbsoluto() {
        return Math.abs(precoReal - precoPredicao);
    }

    /** Erro percentual */
    public double getErroPercentual() {
        if (precoReal == 0) return 0;
        return (getErroAbsoluto() / precoReal) * 100.0;
    }

    @Override
    public String toString() {
        return String.format("Casa[%s] %.0fm² | %dq | %db | %d anos | %.1fkm | %.0f Kz",
            id, areaM2, quartos, banheiros, idadeAnos, distanciaCentroKm, precoReal);
    }
}

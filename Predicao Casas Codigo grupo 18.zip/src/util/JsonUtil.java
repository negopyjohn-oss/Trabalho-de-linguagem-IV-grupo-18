package util;

import model.Casa;
import java.io.*;
import java.nio.file.*;
import java.util.*;

public class JsonUtil {
    private static final String DIR  = "dados_casas";
    private static final String FILE = DIR + "/dataset.json";

    public static void inicializar() {
        try {
            Files.createDirectories(Paths.get(DIR));
            File f = new File(FILE);
            if (!f.exists()) try (FileWriter fw = new FileWriter(f)) { fw.write("[]"); }
        } catch (IOException e) { System.err.println("Erro IO: " + e.getMessage()); }
    }

    public static void salvarCasas(List<Casa> casas) {
        StringBuilder sb = new StringBuilder("[\n");
        for (int i = 0; i < casas.size(); i++) {
            Casa c = casas.get(i);
            sb.append(String.format(
                "  {\"id\":\"%s\",\"areaM2\":%.2f,\"quartos\":%d,\"banheiros\":%d," +
                "\"idadeAnos\":%d,\"distanciaCentroKm\":%.2f,\"precoReal\":%.2f}",
                c.getId(), c.getAreaM2(), c.getQuartos(), c.getBanheiros(),
                c.getIdadeAnos(), c.getDistanciaCentroKm(), c.getPrecoReal()));
            if (i < casas.size() - 1) sb.append(",");
            sb.append("\n");
        }
        sb.append("]");
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE))) { bw.write(sb.toString()); }
        catch (IOException e) { System.err.println("Erro ao salvar: " + e.getMessage()); }
    }

    public static List<Casa> carregarCasas() {
        List<Casa> lista = new ArrayList<>();
        try {
            String conteudo = new String(Files.readAllBytes(Paths.get(FILE)));
            if (conteudo.trim().equals("[]")) return lista;
            // Parser simples de JSON
            conteudo = conteudo.trim();
            if (conteudo.startsWith("[")) conteudo = conteudo.substring(1);
            if (conteudo.endsWith("]"))   conteudo = conteudo.substring(0, conteudo.length() - 1);
            String[] objetos = conteudo.split("\\},\\s*\\{");
            for (String obj : objetos) {
                obj = obj.replace("{", "").replace("}", "").trim();
                Map<String, String> m = new LinkedHashMap<>();
                for (String par : obj.split(",")) {
                    String[] kv = par.split(":", 2);
                    if (kv.length == 2) m.put(kv[0].trim().replace("\"",""), kv[1].trim().replace("\"",""));
                }
                if (m.containsKey("id")) {
                    lista.add(new Casa(m.get("id"),
                        Double.parseDouble(m.getOrDefault("areaM2","0")),
                        Integer.parseInt(m.getOrDefault("quartos","1")),
                        Integer.parseInt(m.getOrDefault("banheiros","1")),
                        Integer.parseInt(m.getOrDefault("idadeAnos","0")),
                        Double.parseDouble(m.getOrDefault("distanciaCentroKm","10")),
                        Double.parseDouble(m.getOrDefault("precoReal","0"))));
                }
            }
        } catch (Exception e) { /* ficheiro ainda não existe */ }
        return lista;
    }
}

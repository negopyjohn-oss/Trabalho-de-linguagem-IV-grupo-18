package service;

import model.Casa;
import model.ResultadoRegressao;

import java.util.List;

/**
 * MotorRegressao — implementa Regressão Linear Múltipla do zero.
 *
 * ================================================================
 * MATEMÁTICA APLICADA (sem bibliotecas externas):
 * ================================================================
 *
 * Modelo: y = Xβ + ε
 *   y  = vetor de preços reais  (n×1)
 *   X  = matriz de features     (n×6)  [1, area, quartos, banheiros, idade, dist]
 *   β  = vetor de coeficientes  (6×1)
 *   ε  = erro (resíduos)
 *
 * Solução OLS (Mínimos Quadrados Ordinários):
 *   β = (XᵀX)⁻¹ Xᵀy
 *
 * Passos:
 *   1. Montar matriz X e vetor y
 *   2. Calcular XᵀX  (produto de X transposta por X)
 *   3. Calcular Xᵀy  (produto de X transposta por y)
 *   4. Inverter XᵀX  (Eliminação de Gauss-Jordan)
 *   5. Multiplicar (XᵀX)⁻¹ por Xᵀy  → β
 *   6. Calcular métricas: R², RMSE, MAE, MAPE
 * ================================================================
 */
public class MotorRegressao {

    private static final int N_FEATURES = 6; // 1(intercepto) + 5 variáveis

    /**
     * Treina o modelo de regressão linear múltipla.
     * Retorna os coeficientes e métricas calculados.
     */
    public ResultadoRegressao treinar(List<Casa> casas) {
        int n = casas.size();
        if (n < N_FEATURES) {
            throw new IllegalArgumentException("Mínimo de " + N_FEATURES + " amostras necessárias.");
        }

        // ── PASSO 1: Montar matriz X (n × 6) e vetor y (n × 1) ─────────
        double[][] X = new double[n][N_FEATURES];
        double[]   y = new double[n];

        for (int i = 0; i < n; i++) {
            Casa c = casas.get(i);
            X[i][0] = 1.0;                        // coluna de 1s → intercepto β0
            X[i][1] = c.getAreaM2();              // β1
            X[i][2] = c.getQuartos();             // β2
            X[i][3] = c.getBanheiros();           // β3
            X[i][4] = c.getIdadeAnos();           // β4
            X[i][5] = c.getDistanciaCentroKm();   // β5
            y[i]    = c.getPrecoReal();
        }

        // ── PASSO 2: XᵀX (matriz 6×6) ───────────────────────────────────
        double[][] XtX = multiplicarMatrizes(transpor(X), X);

        // ── PASSO 3: Xᵀy (vetor 6×1) ────────────────────────────────────
        double[] Xty = multiplicarMatrizVetor(transpor(X), y);

        // ── PASSO 4: Inverter XᵀX via Gauss-Jordan ──────────────────────
        double[][] XtX_inv = inverterGaussJordan(XtX);

        // ── PASSO 5: β = (XᵀX)⁻¹ · Xᵀy ────────────────────────────────
        double[] beta = multiplicarMatrizVetor(XtX_inv, Xty);

        // ── PASSO 6: Calcular predições e métricas ───────────────────────
        ResultadoRegressao resultado = new ResultadoRegressao();
        resultado.setIntercepto  (beta[0]);
        resultado.setCoefArea    (beta[1]);
        resultado.setCoefQuartos (beta[2]);
        resultado.setCoefBanheiros(beta[3]);
        resultado.setCoefIdade   (beta[4]);
        resultado.setCoefDistancia(beta[5]);
        resultado.setNAmostras   (n);

        // Calcular predições e atualizar objetos Casa
        double[] yPred = new double[n];
        for (int i = 0; i < n; i++) {
            yPred[i] = beta[0] + beta[1]*X[i][1] + beta[2]*X[i][2]
                     + beta[3]*X[i][3] + beta[4]*X[i][4] + beta[5]*X[i][5];
            yPred[i] = Math.max(yPred[i], 0);
            casas.get(i).setPrecoPredicao(yPred[i]);
        }

        // Métricas
        resultado.setR2  (calcularR2  (y, yPred));
        resultado.setRmse(calcularRmse(y, yPred));
        resultado.setMae (calcularMae (y, yPred));
        resultado.setMape(calcularMape(y, yPred));

        return resultado;
    }

    // ================================================================
    // OPERAÇÕES DE ÁLGEBRA LINEAR (implementadas do zero)
    // ================================================================

    /**
     * Transposta de uma matriz A (n×m) → Aᵀ (m×n)
     * Aᵀ[j][i] = A[i][j]
     */
    private double[][] transpor(double[][] A) {
        int n = A.length, m = A[0].length;
        double[][] At = new double[m][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < m; j++)
                At[j][i] = A[i][j];
        return At;
    }

    /**
     * Produto de duas matrizes: C = A · B
     * C[i][j] = Σ A[i][k] * B[k][j]
     */
    private double[][] multiplicarMatrizes(double[][] A, double[][] B) {
        int r = A.length, cols = B[0].length, inner = B.length;
        double[][] C = new double[r][cols];
        for (int i = 0; i < r; i++)
            for (int j = 0; j < cols; j++)
                for (int k = 0; k < inner; k++)
                    C[i][j] += A[i][k] * B[k][j];
        return C;
    }

    /**
     * Produto matriz-vetor: b = A · v
     * b[i] = Σ A[i][j] * v[j]
     */
    private double[] multiplicarMatrizVetor(double[][] A, double[] v) {
        int r = A.length, c = v.length;
        double[] b = new double[r];
        for (int i = 0; i < r; i++)
            for (int j = 0; j < c; j++)
                b[i] += A[i][j] * v[j];
        return b;
    }

    /**
     * Inversão de matriz quadrada pelo método de Gauss-Jordan.
     *
     * O método aumenta a matriz [A | I] e aplica operações de linha
     * até obter [I | A⁻¹].
     *
     * Passos:
     *   1. Criar matriz aumentada [A | I]
     *   2. Para cada coluna pivô:
     *      a. Encontrar o pivô (elemento com maior valor absoluto)
     *      b. Trocar linhas se necessário (pivotamento parcial)
     *      c. Normalizar a linha do pivô dividindo pelo pivô
     *      d. Eliminar todos os outros elementos na coluna
     *   3. A parte direita da matriz aumentada é A⁻¹
     */
    private double[][] inverterGaussJordan(double[][] A) {
        int n = A.length;
        // Criar matriz aumentada [A | I]
        double[][] aug = new double[n][2 * n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++)
                aug[i][j] = A[i][j];
            aug[i][i + n] = 1.0; // identidade
        }

        for (int col = 0; col < n; col++) {
            // a) Encontrar pivô com maior valor absoluto (pivotamento parcial)
            int pivotRow = col;
            double maxVal = Math.abs(aug[col][col]);
            for (int row = col + 1; row < n; row++) {
                if (Math.abs(aug[row][col]) > maxVal) {
                    maxVal = Math.abs(aug[row][col]);
                    pivotRow = row;
                }
            }

            // b) Trocar linha col com linha pivotRow
            double[] tmp = aug[col];
            aug[col] = aug[pivotRow];
            aug[pivotRow] = tmp;

            double pivot = aug[col][col];
            if (Math.abs(pivot) < 1e-12)
                throw new ArithmeticException("Matriz singular — regressão inviável com estes dados.");

            // c) Normalizar linha do pivô
            for (int j = 0; j < 2 * n; j++)
                aug[col][j] /= pivot;

            // d) Eliminar coluna em todas as outras linhas
            for (int row = 0; row < n; row++) {
                if (row == col) continue;
                double fator = aug[row][col];
                for (int j = 0; j < 2 * n; j++)
                    aug[row][j] -= fator * aug[col][j];
            }
        }

        // Extrair A⁻¹ (parte direita)
        double[][] inv = new double[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                inv[i][j] = aug[i][j + n];
        return inv;
    }

    // ================================================================
    // MÉTRICAS DE AVALIAÇÃO DO MODELO
    // ================================================================

    /**
     * R² (Coeficiente de Determinação):
     *   R² = 1 - SS_res / SS_tot
     *   SS_res = Σ (yi - ŷi)²   (soma dos quadrados dos resíduos)
     *   SS_tot = Σ (yi - ȳ)²    (variância total)
     *   R² próximo de 1 → modelo muito bom
     */
    private double calcularR2(double[] y, double[] yPred) {
        double media = 0;
        for (double v : y) media += v;
        media /= y.length;

        double ssTot = 0, ssRes = 0;
        for (int i = 0; i < y.length; i++) {
            ssTot += Math.pow(y[i] - media, 2);
            ssRes += Math.pow(y[i] - yPred[i], 2);
        }
        return ssTot == 0 ? 0 : 1.0 - (ssRes / ssTot);
    }

    /**
     * RMSE (Root Mean Square Error):
     *   RMSE = √( Σ (yi - ŷi)² / n )
     *   Quanto menor, melhor. Penaliza erros grandes.
     */
    private double calcularRmse(double[] y, double[] yPred) {
        double soma = 0;
        for (int i = 0; i < y.length; i++)
            soma += Math.pow(y[i] - yPred[i], 2);
        return Math.sqrt(soma / y.length);
    }

    /**
     * MAE (Mean Absolute Error):
     *   MAE = Σ |yi - ŷi| / n
     *   Erro médio absoluto — fácil de interpretar.
     */
    private double calcularMae(double[] y, double[] yPred) {
        double soma = 0;
        for (int i = 0; i < y.length; i++)
            soma += Math.abs(y[i] - yPred[i]);
        return soma / y.length;
    }

    /**
     * MAPE (Mean Absolute Percentage Error):
     *   MAPE = (Σ |yi - ŷi| / |yi|) / n * 100
     *   Erro médio em percentagem.
     */
    private double calcularMape(double[] y, double[] yPred) {
        double soma = 0;
        int count = 0;
        for (int i = 0; i < y.length; i++) {
            if (y[i] != 0) { soma += Math.abs((y[i] - yPred[i]) / y[i]); count++; }
        }
        return count == 0 ? 0 : (soma / count) * 100.0;
    }

    // ================================================================
    // NORMALIZAÇÃO (Z-Score) — opcional, melhora a estabilidade
    // ================================================================

    /** Calcula a média de um array */
    public double media(double[] v) {
        double s = 0;
        for (double x : v) s += x;
        return s / v.length;
    }

    /** Calcula o desvio padrão de um array */
    public double desvioPadrao(double[] v) {
        double m = media(v), s = 0;
        for (double x : v) s += Math.pow(x - m, 2);
        return Math.sqrt(s / v.length);
    }
}

package service;

import model.Casa;
import model.ResultadoRegressao;
import util.JsonUtil;

import java.util.*;

/**
 * GestaoPredicao — coordena o dataset, treino e predições.
 * Padrão Facade: abstrai toda a lógica para a camada UI.
 */
public class GestaoPredicao {

    private List<Casa> dataset;
    private ResultadoRegressao modelo;
    private MotorRegressao motor;
    private boolean modeloTreinado = false;

    public GestaoPredicao() {
        this.motor   = new MotorRegressao();
        this.dataset = new ArrayList<>();
        JsonUtil.inicializar();
        carregarDados();
        if (dataset.isEmpty()) carregarDatasetPadrao();
    }

    // ================================================================
    // DATASET PADRÃO — 30 casas sintéticas realistas (Angola/Luanda)
    // Preços em Kz (mercado imobiliário angolano simplificado)
    // ================================================================
    private void carregarDatasetPadrao() {
        Object[][] dados = {
            //  ID      Área  Q  B  Idade  Dist    Preço($)
            {"C001",  45.0, 1, 1,  5,   15.0,  35000},
            {"C002",  60.0, 2, 1,  3,   12.0,  52000},
            {"C003",  80.0, 2, 2,  8,   10.0,  68000},
            {"C004", 100.0, 3, 2,  2,    8.0,  95000},
            {"C005", 120.0, 3, 2,  6,    6.0, 110000},
            {"C006", 150.0, 4, 3,  1,    4.0, 145000},
            {"C007",  55.0, 1, 1, 15,   18.0,  28000},
            {"C008",  70.0, 2, 1,  10,  14.0,  55000},
            {"C009",  90.0, 3, 2,   4,   7.0,  85000},
            {"C010", 110.0, 3, 2,   2,   5.0, 105000},
            {"C011", 130.0, 4, 3,   7,   3.0, 135000},
            {"C012", 200.0, 5, 4,   1,   2.0, 210000},
            {"C013",  40.0, 1, 1,  20,  20.0,  22000},
            {"C014",  65.0, 2, 1,   9,  11.0,  58000},
            {"C015",  85.0, 2, 2,   5,   9.0,  78000},
            {"C016", 105.0, 3, 2,   3,   6.0,  98000},
            {"C017", 160.0, 4, 3,   4,   3.5, 158000},
            {"C018", 180.0, 5, 3,   2,   2.5, 190000},
            {"C019",  50.0, 1, 1,  12,  16.0,  32000},
            {"C020",  75.0, 2, 2,   7,  13.0,  65000},
            {"C021",  95.0, 3, 2,   6,   8.5,  88000},
            {"C022", 115.0, 3, 3,   1,   5.5, 115000},
            {"C023", 140.0, 4, 3,   3,   4.0, 140000},
            {"C024", 170.0, 5, 4,   5,   2.0, 175000},
            {"C025",  48.0, 1, 1,  18,  22.0,  25000},
            {"C026",  72.0, 2, 1,  11,  15.0,  57000},
            {"C027",  98.0, 3, 2,   4,   7.5,  92000},
            {"C028", 125.0, 4, 2,   8,   5.0, 118000},
            {"C029", 145.0, 4, 3,   2,   3.0, 148000},
            {"C030", 220.0, 6, 4,   1,   1.5, 240000},
        };

        for (Object[] d : dados) {
            dataset.add(new Casa(
                (String) d[0],
                ((Number) d[1]).doubleValue(),
                ((Number) d[2]).intValue(),
                ((Number) d[3]).intValue(),
                ((Number) d[4]).intValue(),
                ((Number) d[5]).doubleValue(),
                ((Number) d[6]).doubleValue()
            ));
        }
        JsonUtil.salvarCasas(dataset);
    }

    // ================================================================
    // TREINO DO MODELO
    // ================================================================

    public ResultadoRegressao treinarModelo() {
        if (dataset.size() < 6) throw new IllegalStateException("Dataset insuficiente (mín. 6 amostras).");
        modelo = motor.treinar(dataset);
        modeloTreinado = true;
        return modelo;
    }

    // ================================================================
    // PREDIÇÃO DE NOVA CASA
    // ================================================================

    public double prever(double area, int quartos, int banheiros, int idade, double distancia) {
        if (!modeloTreinado) treinarModelo();
        return modelo.prever(area, quartos, banheiros, idade, distancia);
    }

    // ================================================================
    // CRUD DO DATASET
    // ================================================================

    public Casa adicionarCasa(double area, int quartos, int banheiros, int idade, double dist, double preco) {
        String id = String.format("C%03d", dataset.size() + 1);
        Casa c = new Casa(id, area, quartos, banheiros, idade, dist, preco);
        dataset.add(c);
        modeloTreinado = false; // modelo precisa ser retreinado
        JsonUtil.salvarCasas(dataset);
        return c;
    }

    public boolean removerCasa(String id) {
        boolean removeu = dataset.removeIf(c -> c.getId().equals(id));
        if (removeu) { modeloTreinado = false; JsonUtil.salvarCasas(dataset); }
        return removeu;
    }

    // ================================================================
    // ESTATÍSTICAS DO DATASET
    // ================================================================

    public Map<String, Double> getEstatisticas() {
        Map<String, Double> stats = new LinkedHashMap<>();
        if (dataset.isEmpty()) return stats;

        DoubleSummaryStatistics area   = dataset.stream().mapToDouble(Casa::getAreaM2).summaryStatistics();
        DoubleSummaryStatistics preco  = dataset.stream().mapToDouble(Casa::getPrecoReal).summaryStatistics();
        DoubleSummaryStatistics dist   = dataset.stream().mapToDouble(Casa::getDistanciaCentroKm).summaryStatistics();

        stats.put("Total de Casas",     (double) dataset.size());
        stats.put("Área Média (m²)",    area.getAverage());
        stats.put("Área Mínima (m²)",   area.getMin());
        stats.put("Área Máxima (m²)",   area.getMax());
        stats.put("Preço Médio ($)",    preco.getAverage());
        stats.put("Preço Mínimo ($)",   preco.getMin());
        stats.put("Preço Máximo ($)",   preco.getMax());
        stats.put("Dist. Média (km)",   dist.getAverage());
        return stats;
    }

    // ================================================================
    // CORRELAÇÃO DE PEARSON entre área e preço (demonstração)
    // Fórmula: r = Σ(xi - x̄)(yi - ȳ) / √[Σ(xi - x̄)² · Σ(yi - ȳ)²]
    // ================================================================
    public double correlacaoPearson(double[] x, double[] y) {
        int n = x.length;
        double mx = motor.media(x), my = motor.media(y);
        double num = 0, dx = 0, dy = 0;
        for (int i = 0; i < n; i++) {
            num += (x[i] - mx) * (y[i] - my);
            dx  += Math.pow(x[i] - mx, 2);
            dy  += Math.pow(y[i] - my, 2);
        }
        return (dx == 0 || dy == 0) ? 0 : num / Math.sqrt(dx * dy);
    }

    public Map<String, Double> getCorrelacoes() {
        if (dataset.isEmpty()) return new LinkedHashMap<>();
        double[] precos   = dataset.stream().mapToDouble(Casa::getPrecoReal).toArray();
        double[] areas    = dataset.stream().mapToDouble(Casa::getAreaM2).toArray();
        double[] quartos  = dataset.stream().mapToDouble(c -> c.getQuartos()).toArray();
        double[] banheiros= dataset.stream().mapToDouble(c -> c.getBanheiros()).toArray();
        double[] idades   = dataset.stream().mapToDouble(c -> c.getIdadeAnos()).toArray();
        double[] dists    = dataset.stream().mapToDouble(Casa::getDistanciaCentroKm).toArray();

        Map<String, Double> cors = new LinkedHashMap<>();
        cors.put("Área × Preço",       correlacaoPearson(areas,    precos));
        cors.put("Quartos × Preço",    correlacaoPearson(quartos,  precos));
        cors.put("Banheiros × Preço",  correlacaoPearson(banheiros,precos));
        cors.put("Idade × Preço",      correlacaoPearson(idades,   precos));
        cors.put("Distância × Preço",  correlacaoPearson(dists,    precos));
        return cors;
    }

    // Getters
    public List<Casa>           getDataset()      { return Collections.unmodifiableList(dataset); }
    public ResultadoRegressao   getModelo()        { return modelo; }
    public boolean              isModeloTreinado() { return modeloTreinado; }

    private void carregarDados() {
        List<Casa> carregadas = JsonUtil.carregarCasas();
        if (carregadas != null) dataset.addAll(carregadas);
    }
}
